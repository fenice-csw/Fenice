FENICE INSTALLATION

#### JAVA 

sudo add-apt-repository ppa:webupd8team/java
sudo apt-get update
sudo apt-get install oracle-java7-installer
sudo apt-get install oracle-java7-set-default

#scaricare jboss 5.x e installare su /opt 
wget https://vorboss.dl.sourceforge.net/project/jboss/JBoss/JBoss-5.1.0.GA/jboss-5.1.0.GA.zip
sudo apt-get install unzip
unzip jboss-5.1.0.GA.zip
#rinominare la cartella server jboss* in Fenice
sudo mv jboss-5.1.0.GA/ /opt/Fenice/
sudo chown -R fenice:fenice /opt/Fenice/

#### [CREAZIONE UTENTE FENICE SE NON C'E' UN UTENTE 'fenice' DI SISTEMA]
sudo adduser --home /opt/Fenice/ fenice
#### [CAMBIO PASSWORD UTENTE FENICE]
sudo passwd fenice

#### Postgres

#@@@@@@@@@ sudo apt-get install postgresql @@@@@@@@@#

sudo su - postgres
psql
CREATE ROLE fenice;
ALTER ROLE fenice WITH SUPERUSER;
ALTER ROLE fenice WITH LOGIN;
CREATE DATABASE db_fenice;
ALTER DATABASE db_fenice OWNER TO fenice;
GRANT ALL PRIVILEGES ON DATABASE db_fenice to fenice;
ALTER USER "fenice" WITH PASSWORD 'fenice';
\q
exit

#### spostare lo script .sql, il feniceWeb.war, il file fenice-ds.xml, le librerie .jar e la directory xsl per le fatturePA sul server 
sudo su - fenice
psql -U fenice -d db_fenice -f Fenice_Init_DB.sql

#### copiare feniceWeb.war sul Fenice jboss web profile dentro la cartella deploy
mv feniceWeb.war /opt/Fenice/server/web/deploy/

#### spostare il file fenice-ds.xml su /opt/Fenice/server/web/deploy/ modificare con i dati del database (IP,Password,etc)
mv fenice-ds.xml /opt/Fenice/server/web/deploy/

#### copiare le librerie postgresql-9.*.jar ed ftp4j-*.jar sul Fenice jboss web profile dentro la cartella lib
mv *.jar /opt/Fenice/server/web/lib/

#### creare due cartelle come figlie della cartella /opt/Fenice di nome: documenti_acquisizione_massiva/ e documenti_protocollo/
mkdir /opt/Fenice/documenti_acquisizione_massiva/
mkdir /opt/Fenice/documenti_protocollo/
sudo chown -R fenice:fenice /opt/Fenice/documenti_*

#### copiare i files delle Fatture PA nella directory documenti_protocollo all'interno di Fenice
unzip FatturePA_XSL.zip
mv xsl/ /opt/Fenice/documenti_protocollo/


#### Creare uno script di avvio del server:
cd /opt/Fenice/bin
nano avvia_fenice.sh
START-->
#!/bin/sh
rm nohup.out
rm -rf ../server/web/work
rm -rf ../server/web/tmp
nohup ./run.sh -c web -b 0.0.0.0 &
<--END
chmod +x avvia_fenice.sh
 
#### Creare uno script di shutdown del server Fenice
cd /opt/Fenice/bin
nano stop_fenice.sh
START-->
#!/bin/bash
FPID=`ps ao pid,command | awk '/\/opt\/Fenice/ { print $1}'`
if [ $FPID ]; then
        echo "Shutting down Fenice[$FPID] ..."
        kill -9 $FPID
fi
echo "Fenice is Stopped"
<--END
chmod +x stop_fenice.sh


#### Avviare Fenice allo startup del sistema
sudo nano /etc/rc.local
START -->
currdir=`pwd`
cd /opt/Fenice/bin
su fenice "./avvia_fenice.sh"
cd $currdir
<--END

#### I logs da consultare dopo il deployment sono fenice_error.log e fenice_debug.log all'interno della directory /opt/Fenice/bin
tail -f fenice_error.log
tail -f fenice_debug.log

### SINCRONIZZAZIONE DATA SISTEMA
sudo apt-get install ntpdate
sudo echo "ntpdate it.pool.ntp.org" > /etc/cron.daily/ntpdate
sudo chmod 755 /etc/cron.daily/ntpdate


